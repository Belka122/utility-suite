
from dataclasses import dataclass
import math

@dataclass
class LoanInput:
    principal: float
    annual_rate: float  # in percent
    years: int

@dataclass
class LoanResult:
    monthly_payment: float
    total_interest: float
    total_paid: float

def annuity(li: LoanInput) -> LoanResult:
    r = li.annual_rate / 100 / 12
    n = li.years * 12
    if r == 0:
        monthly = li.principal / n
    else:
        monthly = li.principal * (r * (1 + r) ** n) / ((1 + r) ** n - 1)
    total_paid = monthly * n
    total_interest = total_paid - li.principal
    return LoanResult(round(monthly, 2), round(total_interest, 2), round(total_paid, 2))
