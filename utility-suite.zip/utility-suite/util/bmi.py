
from dataclasses import dataclass

@dataclass
class BMIResult:
    bmi: float
    category: str
    advice: str

def bmi_calc(weight_kg: float, height_cm: float) -> BMIResult:
    if height_cm <= 0:
        raise ValueError("Pikkus peab olema suurem kui 0")
    h_m = height_cm / 100.0
    bmi = weight_kg / (h_m ** 2)
    category, advice = interpret_bmi(bmi)
    return BMIResult(round(bmi, 2), category, advice)

def interpret_bmi(bmi: float):
    if bmi < 18.5:
        return "Alakaal", "Söö regulaarselt ja lisa energiarikast, toitvat toitu. Kaalu nõustamist spetsialistiga."
    elif bmi < 25:
        return "Normkaal", "Jätka tasakaalustatud toitumist ja mõõdukat liikumist (150 min/ nädal)."
    elif bmi < 30:
        return "Ülekaal", "Vähenda lisatud suhkruid ja väga energiarikast toitu, suurenda liikumist. Vajadusel konsulteeri perearstiga."
    else:
        return "Rasvumine", "Soovitatav on individuaalne plaan koos spetsialistiga (toitumine + liikumine)."
