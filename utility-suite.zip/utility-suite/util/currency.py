
import json
from urllib.request import urlopen
from urllib.error import URLError
from typing import Dict, Optional

API_URL = "https://api.exchangerate.host/latest"

def fetch_rates(base: str = "EUR") -> Dict[str, float]:
    url = f"{API_URL}?base={base.upper()}"
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if not data.get("success", True) and "rates" not in data:
                raise RuntimeError("API error")
            return data["rates"]
    except URLError as e:
        raise ConnectionError(f"Valuutakursi päring ebaõnnestus: {e}")

def convert(amount: float, src: str, dst: str) -> float:
    src = src.upper(); dst = dst.upper()
    if src == dst:
        return amount
    # Strategy: fetch with base=src
    rates = fetch_rates(base=src)
    if dst not in rates:
        # Fallback: fetch base=EUR and cross if needed
        eur_rates = fetch_rates(base="EUR")
        if src not in eur_rates or dst not in eur_rates:
            raise ValueError("Valuuta mitte toetatud.")
        # amount in EUR then to dst
        amount_eur = amount / eur_rates[src]
        return amount_eur * eur_rates[dst]
    return amount * rates[dst]
