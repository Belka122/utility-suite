
import random
import string
from dataclasses import dataclass

@dataclass
class PasswordOptions:
    length: int = 16
    uppercase: bool = True
    lowercase: bool = True
    digits: bool = True
    symbols: bool = True
    avoid_ambiguous: bool = True  # e.g., O/0, l/1

AMBIGUOUS = set("O0oIl1|{}[]()<>`'";:,./\\")

def generate_password(opts: PasswordOptions) -> str:
    pools = []
    if opts.uppercase: pools.append([c for c in string.ascii_uppercase if (c not in AMBIGUOUS or not opts.avoid_ambiguous)])
    if opts.lowercase: pools.append([c for c in string.ascii_lowercase if (c not in AMBIGUOUS or not opts.avoid_ambiguous)])
    if opts.digits:    pools.append([c for c in string.digits if (c not in AMBIGUOUS or not opts.avoid_ambiguous)])
    if opts.symbols:   pools.append([c for c in string.punctuation if (c not in AMBIGUOUS or not opts.avoid_ambiguous)])
    if not pools:
        raise ValueError("Vali vähemalt üks sümbolite grupp.")
    # ensure at least one from each chosen pool
    password_chars = [random.choice(pool) for pool in pools]
    all_chars = [c for pool in pools for c in pool]
    remaining = max(opts.length - len(password_chars), 0)
    password_chars += [random.choice(all_chars) for _ in range(remaining)]
    random.shuffle(password_chars)
    return "".join(password_chars)

def random_int(a: int, b: int) -> int:
    return random.randint(a, b)
