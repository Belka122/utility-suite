
from dataclasses import dataclass

# --- Temperature ---
def c_to_f(c: float) -> float:
    return c * 9/5 + 32

def f_to_c(f: float) -> float:
    return (f - 32) * 5/9

def c_to_k(c: float) -> float:
    return c + 273.15

def k_to_c(k: float) -> float:
    return k - 273.15

def f_to_k(f: float) -> float:
    return c_to_k(f_to_c(f))

def k_to_f(k: float) -> float:
    return c_to_f(k_to_c(k))

# General temperature convert
def convert_temperature(value: float, src: str, dst: str) -> float:
    s = src.lower(); d = dst.lower()
    if s == d:
        return value
    # map to C as pivot
    if s == "c":
        c = value
    elif s == "f":
        c = f_to_c(value)
    elif s == "k":
        c = k_to_c(value)
    else:
        raise ValueError("Unknown temperature unit: use C, F, or K")
    if d == "c":
        return c
    elif d == "f":
        return c_to_f(c)
    elif d == "k":
        return c_to_k(c)
    else:
        raise ValueError("Unknown temperature unit: use C, F, or K")

# --- Length ---
_LENGTH_FACTORS_TO_M = {
    "mm": 0.001,
    "cm": 0.01,
    "m": 1.0,
    "km": 1000.0,
    "in": 0.0254,
    "ft": 0.3048,
    "yd": 0.9144,
    "mi": 1609.344,
}

def convert_length(value: float, src: str, dst: str) -> float:
    s, d = src.lower(), dst.lower()
    if s not in _LENGTH_FACTORS_TO_M or d not in _LENGTH_FACTORS_TO_M:
        raise ValueError(f"Tundmatu pikkuse ühik. Kasuta: {', '.join(sorted(_LENGTH_FACTORS_TO_M.keys()))}")
    meters = value * _LENGTH_FACTORS_TO_M[s]
    return meters / _LENGTH_FACTORS_TO_M[d]

# --- Mass ---
_MASS_FACTORS_TO_KG = {
    "mg": 1e-6,
    "g": 1e-3,
    "kg": 1.0,
    "t": 1000.0,
    "lb": 0.45359237,
    "oz": 0.028349523125,
}

def convert_mass(value: float, src: str, dst: str) -> float:
    s, d = src.lower(), dst.lower()
    if s not in _MASS_FACTORS_TO_KG or d not in _MASS_FACTORS_TO_KG:
        raise ValueError(f"Tundmatu massi ühik. Kasuta: {', '.join(sorted(_MASS_FACTORS_TO_KG.keys()))}")
    kg = value * _MASS_FACTORS_TO_KG[s]
    return kg / _MASS_FACTORS_TO_KG[d]
